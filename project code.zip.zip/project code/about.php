<?php

@include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<section class="about">

   <div class="row">

      <div class="box">
         <img src="images/about-img-1.png" alt="">
         <h3>why choose us?</h3>
         <p>we're committed to growing the purest produce possible that is grown with farmers and delivered straight to your door step.. 
         Our farms are close to where your home is creating a complete transparent supply chain with low-carbon footprint. Also they are filled with nutrients and wholesome goodness harvested just minutes away before delivery.
         </p>
         <a href="contact.php" class="btn">contact us</a>
      </div>

      <div class="box">
         <img src="images/about-img-2.png" alt="">
         <h3>what we provide?</h3>
         <p>At AgroCulture, Our farms are close to where your home is. Every choice we make brings you vegetables at the height of freshness, flavor & nutrition.</p>
         <a href="shop.php" class="btn">our shop</a>
      </div>

   </div>

</section>

<section class="reviews">

   <h1 class="title">clients reivews</h1>

   <div class="box-container">

      <div class="box">
         <img src="images/pic-1.png" alt="">
      <p>AgroCulture has really nailed their produce and they grow these in their amazing organic farms. You can order fruits and vegitables their other fresh greens on AgroCulture</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>john</h3>
      </div>

      <div class="box">
         <img src="images/pic-2.png" alt="">
         <p>Ordered a couple of platters from Daily Fresh, was very impressed with the presentation. Team is very helpful and they make sure to communicate with you so you are happy with products. The platters were very fresh and very tasty. Good value for money. Also there is an incredible variety of fresh veggies and fruits in AgroCulture</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Samantha</h3>
      </div>

      <div class="box">
         <img src="images/pic-3.png" alt="">
         <p>Wonderful selection of fresh fruit and great deli counter,Great selection,Organic products,Fresh food,Speed Delivery,Local procedure,Health food</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Rama Rao</h3>
      </div>

      <div class="box">
         <img src="images/pic-4.png" alt="">
         <p>Absolutely amazing place to go AgroCulture. The staff and owners are extremely helpful and friendly. I feel at home when i shop there, never ending variety of healthy foods, fresh veggies and fruit. Highly recommend !!! Also pick up service is so
convenient, fast and easy. Thank you AgroCulture for your service !!!</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Laxmi</h3>
      </div>

      <div class="box">
         <img src="images/pic-5.png" alt="">
         <p>A clean and well organized AgroCulture with lots of unconventional organic items to choose from. Staff is super friendly and the delicatessen is spectacular.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Tom</h3>
      </div>

      <div class="box">
         <img src="images/pic-6.png" alt="">
         <p>   popped these tomatoes right after shooting and damn, were they sweet and delicious! AgroCulture has really nailed their produce and they grow these in their amazing hydroponic farms. You can order these cherry tomatoes and their other fresh greens on AgroCulture</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Rakul</h3>
      </div>

   </div>

</section>









<?php include 'footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>